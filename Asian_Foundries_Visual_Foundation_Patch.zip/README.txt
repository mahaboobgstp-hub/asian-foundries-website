Apply from the asian-foundries-website repository root on branch asian-foundries-redesign.
Run: python3 apply_foundation.py
Then: npm run build
This does not add dependencies or remove routes. It only updates src/App.jsx, src/main.jsx, index.html and adds src/foundation.css.
