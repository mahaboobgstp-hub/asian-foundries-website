#!/usr/bin/env python3
from pathlib import Path
root=Path.cwd()
app=root/"src/App.jsx"; main=root/"src/main.jsx"; index=root/"index.html"
for p in (app,main,index):
    if not p.exists(): raise SystemExit(f"Run from repository root; missing {p}")
a=app.read_text(encoding="utf-8")
old='<h1>Engineered in iron.<br/><em>Made for industry.</em></h1><p>Grey Iron and SG Iron castings for the components, machines and systems that move industries forward.</p>'
new='<h1>Engineered in<br/>Castings.<br/><em>Designed for Tomorrow.</em></h1><p>Grounded in foundry experience. Focused on the next generation of cast components, engineering partnerships and industrial possibilities.</p>'
if old not in a: raise SystemExit("Homepage hero text did not match. Nothing changed.")
m=main.read_text(encoding="utf-8")
if "import './foundation.css'" not in m:
    if "import './styles.css'" not in m: raise SystemExit("Could not find styles.css import.")
    m=m.replace("import './styles.css'","import './styles.css'\nimport './foundation.css'",1)
i=index.read_text(encoding="utf-8")
i=i.replace("Asian Foundries | Engineered in Iron","Asian Foundries | Engineered in Castings. Designed for Tomorrow.")
i=i.replace("Asian Foundries Private Limited | Engineered in Iron","Asian Foundries Private Limited | Engineered in Castings. Designed for Tomorrow.")
i=i.replace("Grey Iron and SG Iron castings for multi-industry applications.","Engineered in Castings. Designed for Tomorrow. Grey Iron and SG Iron castings for multi-industry applications.")
f=root/"src/foundation.css"
if f.exists(): raise SystemExit("src/foundation.css already exists; inspect before replacing.")
f.write_text((Path(__file__).parent/"src/foundation.css").read_text(encoding="utf-8"),encoding="utf-8")
a=a.replace(old,new,1); app.write_text(a,encoding="utf-8")
main.write_text(m,encoding="utf-8"); index.write_text(i,encoding="utf-8")
print("Applied visual foundation: CSS, homepage tagline, stylesheet import and page metadata.")
